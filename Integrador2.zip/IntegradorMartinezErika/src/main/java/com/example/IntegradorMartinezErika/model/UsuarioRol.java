package com.example.IntegradorMartinezErika.model;

public enum UsuarioRol {

    USER, ADMIN
}

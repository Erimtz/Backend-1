package com.example.IntegradorMartinezErika.service;


import com.example.IntegradorMartinezErika.exceptions.BadRequestException;
import com.example.IntegradorMartinezErika.exceptions.ResourceNotFoundException;
import com.example.IntegradorMartinezErika.model.Odontologo;
import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertThrows;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(SpringRunner.class)
@SpringBootTest
public class Odontologo1 {
    @Autowired
    private OdontologoService odontologoService;

    @Test
    public void guardarOdontologo() throws BadRequestException, ResourceNotFoundException {
        Odontologo odontologo = new Odontologo("ABC123","Andres","Monterrosa");
        Odontologo odontologoCreado = odontologoService.guardar(odontologo);
        assertNotNull(odontologoService.buscar(odontologoCreado.getId()));
    }

    @Test
    public void buscarPorId() throws BadRequestException, ResourceNotFoundException {
        Odontologo odontologo = odontologoService.guardar(new Odontologo("ABC123","Andres","Monterrosa"));
        Odontologo odontologoABuscar = odontologoService.buscar(odontologo.getId());
        assertNotNull(odontologoABuscar);
        assertEquals("Andres", odontologoABuscar.getNombre());
    }

    @Test
    public void eliminarOdontologoTest() throws ResourceNotFoundException, BadRequestException {
        Odontologo odontologo = odontologoService.guardar(new Odontologo("ABC123","Andres","Monterrosa"));
        odontologoService.eliminar(odontologo.getId());

        Throwable exception = assertThrows(ResourceNotFoundException.class, () ->odontologoService.eliminar(odontologo.getId()));
        assertEquals("No existe un odontologo con el ID:" + odontologo.getId(), exception.getMessage());
    }

    @Test
    public void actualizarOdontologoTest() throws BadRequestException, ResourceNotFoundException {
        Odontologo odontologoCreado = odontologoService.guardar(new Odontologo("ABC123","Andres","Monterrosa"));
        assertEquals("Andres", odontologoCreado.getNombre());
        odontologoCreado.setNombre("Felipe");
        Odontologo odontologoActualizado = odontologoService.actualizar(odontologoCreado);
        assertEquals("Felipe", odontologoCreado.getNombre());
    }

    @Test
    public void listarTodos(){
        Odontologo odontologo = new Odontologo("ABC123","Andres","Monterrosa");
        odontologoService.guardar(odontologo);
        List<Odontologo> odontologos = odontologoService.buscarTodos();
        assertFalse(odontologos.isEmpty());
    }
}

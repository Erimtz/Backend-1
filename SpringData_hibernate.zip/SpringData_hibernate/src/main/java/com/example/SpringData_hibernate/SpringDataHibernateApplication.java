package com.example.SpringData_hibernate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataHibernateApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringDataHibernateApplication.class, args);
	}

}

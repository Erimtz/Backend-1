package com.example.SpringData_hibernate.model;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "equipos")
public class Equipo {

    @Id
    @SequenceGenerator(name = "equipo_sequence", sequenceName = "equipo_sequence")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "equipo_sequence")

    private Long id;
    private String nombre;
    private String ciudad;

    @OneToMany(mappedBy = "equipo", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private Set<Jugador> jugadores = new HashSet<>();
    //private List<Jugador> jugadores;


    public Equipo() {
    }

    public Equipo(String nombre, String ciudad) {
        this.nombre = nombre;
        this.ciudad = ciudad;
    }

    public Long getId() {
        return id;
    }

    public Set<Jugador> getJugadores() {
        return jugadores;
    }
}

package com.example.SpringData_hibernate.model;

import javax.persistence.*;

@Entity
@Table(name = "jugadores")
public class Jugador {

    @Id
    @SequenceGenerator(name = "jugador_sequence", sequenceName = "jugador_sequence")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequence, generator")

    private int numero;
    private String nombre;
    private String puesto;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "equipo_id")
    private Equipo equipo;


    public Jugador() {
    }

    public Jugador(String nombre, String puesto) {
        this.nombre = nombre;
        this.puesto = puesto;
    }

    public int getNumero() {
        return numero;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPuesto() {
        return puesto;
    }

    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }
}

package com.example.SpringData_hibernate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataHibernateApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.example.TP_clinicaOdontologica;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TpClinicaOdontologicaApplication {

	public static void main(String[] args) {
		SpringApplication.run(TpClinicaOdontologicaApplication.class, args);
	}

}

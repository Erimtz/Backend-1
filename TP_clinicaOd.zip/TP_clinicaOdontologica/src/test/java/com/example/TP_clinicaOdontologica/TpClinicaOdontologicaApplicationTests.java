package com.example.TP_clinicaOdontologica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpClinicaOdontologicaApplicationTests {

	@Test
	void contextLoads() {
	}

}
